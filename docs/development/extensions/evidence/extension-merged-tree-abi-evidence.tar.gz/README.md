# Merged-tree extension ABI evidence (macOS arm64, 2026-11-03)

Receipts and logs of the merged-tree host row described in abi-review.md:
the unchanged Sedona and Nutmeg wheel pair of the examples re-pin unit run by
check_compatibility.py against three gate-built hosts (hosts.json), and the
refusal/lease probes of check_abi_boundaries.py against the merged tip,
including the retained stale-fixture failure (boundaries-stale-fixtures/).
gate-*.log and native-*.log are the merge gates that built the three hosts.
check_abi_boundaries-before.py and -after.py are the runner before and after
the fixture correction. Binaries, wheels and pytest base temporary trees
(server logs and data) are omitted; their hashes remain in the receipts.
Absolute paths are redacted (<scratchpad>, /Users/<user>).

Verify after extraction with `shasum -a 256 -c SHA256SUMS`.
